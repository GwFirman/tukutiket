<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex h-screen w-screen sm:justify-center items-center p-20">
        <div class="flex h-full bg-white shadow-md overflow-hidden sm:rounded-lg">

            
            <div class="w-full h-full sm:rounded-lg">
                <div class="text-center h-full">
                    <img src="<?php echo e(asset('images/login.png')); ?>" alt="Kreator Illustration"
                        class="w-full h-full object-cover">
                </div>
            </div>

            
            <div class="px-28 py-8 w-256">
                <div class="flex gap-4 mb-6">
                    <div class="bg-gradient-to-r from-indigo-600 to-purple-600 p-2 rounded-lg">
                        <i data-lucide="badge-check" class="w-8 h-8 text-white"></i>
                    </div>

                    <div class="">
                        <h1 class="text-lg text-gray-800 font-bold">Daftar Sebagai Kreator</h1>
                        <p class="text-sm text-gray-600">
                            Buat profil kreator & mulai buat event!
                        </p>
                    </div>
                </div>

                <form method="POST" action="<?php echo e(route('kreator.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    
                    <div class="mb-6">
                        <label class="block text-gray-700 font-medium mb-2">Logo Kreator</label>

                        <div class="flex items-center gap-4">

                            <div class="relative">
                                
                                <img id="previewImage" src="https://placehold.net/shape.svg"
                                    class="h-28 w-28 rounded-full object-cover shadow ">

                                
                                <button type="button" onclick="document.getElementById('logoInput').click()"
                                    class="absolute bottom-1 right-1 bg-white p-1 rounded-full shadow hover:bg-gray-100 border">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-600"
                                        viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M11 5h-5a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.586-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                    </svg>
                                </button>
                            </div>

                        </div>

                        
                        <input type="file" name="logo" id="logoInput" accept="image/*" class="hidden"
                            onchange="previewSelectedImage(event)">

                        <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-gray-700 font-semibold mb-1">Nama Kreator</label>
                        <input type="text" name="nama_kreator" required
                            class="block w-full rounded-lg py-2 px-4 outline outline-gray-300 focus:outline-indigo-500"
                            placeholder="Masukkan nama kreator">
                        <?php $__errorArgs = ['nama_kreator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-6">
                        <label class="block text-gray-700 font-medium mb-2">Deskripsi Kreator</label>
                        <textarea name="deskripsi" rows="3"
                            class="w-full rounded-lg py-2 px-4  outline outline-gray-300 focus:outline-indigo-500"
                            placeholder="Deskripsi singkat kreator..."></textarea>
                        <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>



                    
                    <div class="w-full mt-8">
                        <button type="submit"
                            class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-6 rounded-lg">
                            Buat Profil Kreator
                        </button>
                    </div>
                </form>

                <div class="text-center mt-6 pt-4 border-t border-gray-200">
                    <p class="text-sm text-gray-600">
                        Batal?
                        <a href="<?php echo e(route('beranda')); ?>" class="text-indigo-600 hover:text-indigo-800 font-medium">
                            Kembali ke Beranda
                        </a>
                    </p>
                </div>

            </div>
        </div>
    </div>

    
    <script>
        function previewSelectedImage(event) {
            const file = event.target.files[0];
            if (!file) return;
            document.getElementById('previewImage').src = URL.createObjectURL(file);
        }
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH D:\Kulyeah\magang\Project\tukutiket\resources\views/pembuat_acara/register.blade.php ENDPATH**/ ?>
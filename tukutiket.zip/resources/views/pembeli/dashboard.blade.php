<x-pembeli-layout>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    Dashboard pembeli

                    <script src="https://unpkg.com/lucide@latest"></script>
                    <script>
                        lucide.createIcons();
                    </script>
                </div>
            </div>
        </div>
    </div>
</x-pembeli-layout>

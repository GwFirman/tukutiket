<?php

namespace App\Livewire\Pembuat\Form;

use Livewire\Component;

class FormImage extends Component
{
    public function render()
    {
        return view('livewire.pembuat.form.form-image');
    }
}

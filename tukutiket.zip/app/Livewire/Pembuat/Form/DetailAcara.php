<?php

namespace App\Livewire\Pembuat\Form;

use Livewire\Component;

class DetailAcara extends Component
{
    public function render()
    {
        return view('livewire.pembuat.form.detail-acara');
    }
}

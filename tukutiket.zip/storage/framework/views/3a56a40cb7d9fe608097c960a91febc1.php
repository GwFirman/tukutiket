<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800">
            Profil Penyelenggara
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-10">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            <?php if(session('success')): ?>
                <div class="mb-4 p-4 bg-green-100 text-green-700 rounded-lg">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-white shadow-sm rounded-lg p-6">
                <div class="flex items-start gap-6">

                    
                    <div>
                        <?php if($penyelenggara && $penyelenggara->logo): ?>
                            <img src="<?php echo e(Storage::url($penyelenggara->logo)); ?>"
                                class="h-32 w-32 rounded-lg object-cover border shadow-sm">
                        <?php else: ?>
                            <div class="h-32 w-32 bg-gray-200 flex items-center justify-center rounded-lg border">
                                <span class="text-sm text-gray-500">Tidak ada logo</span>
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <div>
                        <h3 class="text-xl font-bold text-gray-800">
                            <?php echo e($penyelenggara->nama_penyelenggara ?? 'Belum ada nama'); ?>

                        </h3>
                        <p class="text-gray-600 mt-2">
                            <?php echo e($penyelenggara->deskripsi ?? 'Belum ada deskripsi.'); ?>

                        </p>

                        <p class="text-gray-600 mt-4">
                            <strong>Kontak:</strong> <?php echo e($penyelenggara->kontak ?? '-'); ?>

                        </p>
                    </div>
                </div>

                <hr class="my-8">

                <h3 class="text-lg font-semibold text-gray-800 mb-4">Edit Profil Penyelenggara</h3>

                <form method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="space-y-4">

                        <div>
                            <label class="block font-medium text-gray-700">Nama Penyelenggara</label>
                            <input type="text" name="nama_penyelenggara"
                                value="<?php echo e(old('nama_penyelenggara', $penyelenggara->nama_penyelenggara)); ?>"
                                class="w-full mt-1 border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                        </div>

                        <div>
                            <label class="block font-medium text-gray-700">Deskripsi</label>
                            <textarea name="deskripsi" rows="4"
                                class="w-full mt-1 border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500"><?php echo e(old('deskripsi', $penyelenggara->deskripsi)); ?></textarea>
                        </div>

                        <div>
                            <label class="block font-medium text-gray-700">Kontak (Email / Nomor)</label>
                            <input type="text" name="kontak" value="<?php echo e(old('kontak', $penyelenggara->kontak)); ?>"
                                class="w-full mt-1 border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                        </div>

                        <div>
                            <label class="block font-medium text-gray-700">Logo Penyelenggara</label>
                            <input type="file" name="logo" class="mt-2">
                            <p class="text-sm text-gray-500 mt-1">Format: jpg, jpeg, png, webp (maks 2MB)</p>
                        </div>

                        <div class="pt-4">
                            <button type="submit"
                                class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                                Simpan Perubahan
                            </button>
                        </div>

                    </div>

                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Kulyeah\magang\Project\tukutiket\resources\views/pembuat_acara/penyelenggara/index.blade.php ENDPATH**/ ?>
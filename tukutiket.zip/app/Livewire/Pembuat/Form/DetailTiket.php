<?php

namespace App\Livewire\Pembuat\Form;

use Livewire\Component;

class DetailTiket extends Component
{
    public function render()
    {
        return view('livewire.pembuat.form.detail-tiket');
    }
}

<div style="text-align: center">
    <button wire:click="increment">+</button>
    <h1><?php echo e($count); ?></h1>
</div><?php /**PATH D:\Kulyeah\magang\Project\tukutiket\resources\views/livewire/counter.blade.php ENDPATH**/ ?>
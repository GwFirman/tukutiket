<?php

namespace App\Livewire\Pembuat\Form;

use Livewire\Component;

class FormAcara extends Component
{
    public function render()
    {
        return view('livewire.pembuat.form.form-acara');
    }
}

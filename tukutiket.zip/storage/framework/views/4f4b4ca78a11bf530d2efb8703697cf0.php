<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-6xl mx-auto py-10">

        
        <h1 class="text-3xl font-bold text-gray-800 mb-6">
            Laporan Penjualan — <?php echo e($acara->nama_acara); ?>

        </h1>

        
        <div class="bg-white shadow rounded-xl p-6 mb-10">
            <h2 class="text-xl font-semibold text-gray-700 mb-4">Rekap Penjualan Acara</h2>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-6">

                <div class="p-4 border rounded-lg bg-gray-50">
                    <p class="text-sm text-gray-500">Total Transaksi</p>
                    <p class="text-2xl font-bold"><?php echo e($rekapAcara->total_transaksi); ?></p>
                </div>

                <div class="p-4 border rounded-lg bg-gray-50">
                    <p class="text-sm text-gray-500">Tiket Terjual</p>
                    <p class="text-2xl font-bold"><?php echo e($rekapAcara->total_tiket_terjual); ?></p>
                </div>

                <div class="p-4 border rounded-lg bg-gray-50">
                    <p class="text-sm text-gray-500">Pendapatan</p>
                    <p class="text-2xl font-bold">
                        Rp <?php echo e(number_format($rekapAcara->total_pendapatan, 0, ',', '.')); ?>

                    </p>
                </div>

                <div class="p-4 border rounded-lg bg-gray-50">
                    <p class="text-sm text-gray-500">Sudah Check-in</p>
                    <p class="text-2xl font-bold"><?php echo e($rekapAcara->total_sudah_checkin); ?></p>
                </div>

            </div>
        </div>



        
        <div class="bg-white shadow rounded-xl p-6">
            <h2 class="text-xl font-semibold text-gray-700 mb-4">Detail Penjualan Per Jenis Tiket</h2>

            <div class="overflow-x-auto">
                <table class="w-full border-collapse">
                    <thead>
                        <tr class="bg-gray-100 text-gray-600 text-sm">
                            <th class="border p-3">Jenis Tiket</th>
                            <th class="border p-3">Harga</th>
                            <th class="border p-3">Kuota</th>
                            <th class="border p-3">Terjual</th>
                            <th class="border p-3">Sisa Kuota</th>
                            <th class="border p-3">Pendapatan</th>
                            <th class="border p-3">Check-in</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $rekapJenisTiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-sm text-gray-700">
                                <td class="border p-3 font-medium"><?php echo e($jt->nama_jenis); ?></td>

                                <td class="border p-3">
                                    Rp <?php echo e(number_format($jt->harga, 0, ',', '.')); ?>

                                </td>

                                <td class="border p-3 text-center"><?php echo e($jt->kuota); ?></td>
                                <td class="border p-3 text-center"><?php echo e($jt->tiket_terjual); ?></td>
                                <td class="border p-3 text-center"><?php echo e($jt->sisa_kuota); ?></td>

                                <td class="border p-3">
                                    Rp <?php echo e(number_format($jt->pendapatan, 0, ',', '.')); ?>

                                </td>

                                <td class="border p-3 text-center"><?php echo e($jt->checkin_count); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Kulyeah\magang\Project\tukutiket\resources\views/pembuat_acara/acara/laporan-penjualan.blade.php ENDPATH**/ ?>
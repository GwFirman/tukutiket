<?php if (isset($component)) { $__componentOriginalc8f90efea79093865b729deab0655b79 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8f90efea79093865b729deab0655b79 = $attributes; } ?>
<?php $component = App\View\Components\PembeliLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pembeli-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PembeliLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    Dashboard pembeli

                    <script src="https://unpkg.com/lucide@latest"></script>
                    <script>
                        lucide.createIcons();
                    </script>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8f90efea79093865b729deab0655b79)): ?>
<?php $attributes = $__attributesOriginalc8f90efea79093865b729deab0655b79; ?>
<?php unset($__attributesOriginalc8f90efea79093865b729deab0655b79); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8f90efea79093865b729deab0655b79)): ?>
<?php $component = $__componentOriginalc8f90efea79093865b729deab0655b79; ?>
<?php unset($__componentOriginalc8f90efea79093865b729deab0655b79); ?>
<?php endif; ?>
<?php /**PATH D:\Kulyeah\magang\Project\tukutiket\resources\views/pembeli/dashboard.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2 mb-4">
            <i data-lucide="home" class="size-5 text-gray-600"></i>
            <i data-lucide="chevron-right" class="size-4 font-medium text-gray-400"></i>
            <p class="font-medium">Dashboard</p>
        </div>
     <?php $__env->endSlot(); ?>
    <div class="">
        <div class="px-24">
            <!-- Dashboard Header -->
            <div class="mb-6 flex justify-between items-center">
                <h1 class="text-2xl font-semibold text-gray-800">Dashboard Pembuat Acara</h1>
                <a href="<?php echo e(route('pembuat.acara.create')); ?>"
                    class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                    Buat Acara Baru
                </a>
            </div>

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <div class="bg-white rounded-lg shadow p-5">
                    <div class="flex justify-between">
                        <div>
                            <h2 class="text-gray-500 text-sm">Total Acara</h2>
                            <p class="text-xl font-bold"><?php echo e($totalAcara); ?></p>
                        </div>
                        <div class="bg-indigo-400 p-3 rounded-full">
                            <i data-lucide="calendar" class="size-6 font-medium text-white"></i>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-5">
                    <div class="flex justify-between">
                        <div>
                            <h2 class="text-gray-500 text-sm">Tiket Terjual</h2>
                            <p class="text-xl font-bold"><?php echo e($totalTiketTerjual); ?></p>
                        </div>
                        <div class="bg-purple-400 p-3 rounded-full">
                            <i data-lucide="ticket" class="size-6 font-medium text-white"></i>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-5">
                    <div class="flex justify-between">
                        <div>
                            <h2 class="text-gray-500 text-sm">Pendapatan</h2>
                            <p class="text-xl font-bold">Rp <?php echo e(number_format($totalPendapatan, 0, ',', '.')); ?></p>
                        </div>
                        <div class="bg-green-400 p-3 rounded-full">
                            <i data-lucide="banknote-arrow-down" class="size-6 font-medium text-white"></i>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-5">
                    <div class="flex justify-between">
                        <div>
                            <h2 class="text-gray-500 text-sm">Pengunjung</h2>
                            <p class="text-xl font-bold"><?php echo e($totalPeserta); ?></p>
                        </div>
                        <div class="bg-amber-400 p-3 rounded-full">
                            <i data-lucide="users" class="size-6 font-medium text-white"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Events Table -->
            

            <!-- Quick Links -->
            
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Kulyeah\magang\Project\tukutiket\resources\views/pembuat_acara/dashboard.blade.php ENDPATH**/ ?>
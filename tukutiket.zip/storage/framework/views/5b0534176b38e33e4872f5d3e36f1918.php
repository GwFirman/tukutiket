<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-12 gap-2">
                <div class="bg-white shadow-sm sm:rounded-lg col-span-8 p-4">
                    <div
                        class="h-64 w-full border-2 border-gray-200 border-dashed rounded-lg flex items-center justify-center overflow-hidden bg-gray-50">
                        <?php if($acara->banner_acara): ?>
                            <img src="<?php echo e(asset('storage/' . $acara->banner_acara)); ?>" alt="Banner Acara"
                                class="h-full w-full object-cover rounded-lg">
                        <?php else: ?>
                            <span class="text-gray-400 text-sm">Belum ada banner acara</span>
                        <?php endif; ?>
                    </div>

                    <div class=" text-gray-900 mt-4 text-2xl">
                        <?php echo e($acara->nama_acara); ?>

                    </div>
                    <div class="border-t border-gray-200 my-4"></div>
                    <div class=" text-gray-400 mt-4 font-medium text-lg">
                        Informasi tiket
                    </div>
                    <div class="grid grid-cols-1 gap-4 mt-2">
                        <?php $__currentLoopData = $acara->jenisTiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition"
                                onclick="toggleTicketDetails('ticket-<?php echo e($tiket->id); ?>')">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <h3 class="font-semibold text-lg"><?php echo e($tiket->nama_jenis); ?></h3>
                                        <p class="text-gray-500">Rp <?php echo e(number_format($tiket->harga, 0, ',', '.')); ?></p>
                                    </div>
                                    <div>
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 chevron-icon"
                                            fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M19 9l-7 7-7-7" />
                                        </svg>
                                    </div>
                                </div>

                                <div id="ticket-<?php echo e($tiket->id); ?>" class="hidden mt-4 pt-4 border-t border-gray-200">
                                    <div class="grid grid-cols-2 gap-2 text-sm">
                                        <div>
                                            <p class="text-gray-600">Tanggal Mulai:</p>
                                            <p><?php echo e(\Carbon\Carbon::parse($tiket->penjualan_mulai)->format('d-m-Y')); ?>

                                                <span
                                                    class="text-gray-500"><?php echo e(\Carbon\Carbon::parse($tiket->penjualan_mulai)->format('H:i')); ?></span>
                                            </p>
                                        </div>
                                        <div>
                                            <p class="text-gray-600">Tanggal Selesai:</p>
                                            <p><?php echo e(\Carbon\Carbon::parse($tiket->penjualan_selesai)->format('d-m-Y')); ?>

                                                <span
                                                    class="text-gray-500"><?php echo e(\Carbon\Carbon::parse($tiket->penjualan_selesai)->format('H:i')); ?></span>
                                            </p>
                                        </div>
                                        <div>
                                            <p class="text-gray-600">Jumlah Tiket:</p>
                                            <p><?php echo e($tiket->jumlah_tiket); ?></p>
                                        </div>
                                        <div>
                                            <p class="text-gray-600">Status:</p>
                                            <p><?php echo e($tiket->status); ?></p>
                                        </div>
                                    </div>
                                    <div class="mt-4">
                                        <p class="text-gray-600">Deskripsi:</p>
                                        <p><?php echo e($tiket->deskripsi ?? 'Tidak ada deskripsi'); ?></p>
                                    </div>
                                    <div class="mt-4">
                                        <a href="<?php echo e(route('pembuat.acara.edit', $tiket->id)); ?>"
                                            class="text-blue-500 hover:underline">Edit Tiket</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <script>
                        function toggleTicketDetails(ticketId) {
                            const element = document.getElementById(ticketId);
                            const chevronIcon = event.currentTarget.querySelector('.chevron-icon');

                            if (element.classList.contains('hidden')) {
                                element.classList.remove('hidden');
                                chevronIcon.innerHTML =
                                    '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />';
                            } else {
                                element.classList.add('hidden');
                                chevronIcon.innerHTML =
                                    '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />';
                            }
                        }
                    </script>

                </div>
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg col-span-4 p-6">
                    <div class=" text-gray-800 text-xl font-medium">
                        <?php echo e($acara->nama_acara); ?>

                    </div>
                    <div class="text-gray-600 mt-2">
                        <?php echo e($acara->deskripsi); ?>

                    </div>
                    <div class="border-t border-gray-200 my-4"></div>
                    <p class="text-gray-800 font-medium">Waktu Pelaksanaan</p>
                    <div class="flex gap-2 mt-2">
                        <div class="bg-gray-100 rounded-md border border-gray-400 p-2">
                            <p><?php echo e(\Carbon\Carbon::parse($acara->penjualan_mulai)->format('d-m-Y')); ?> <span
                                    class="text-gray-500"><?php echo e(\Carbon\Carbon::parse($acara->waktu_mulai)->format('H:i')); ?></span>
                            </p>
                        </div>
                        <div class="bg-gray-100 rounded-md border border-gray-400 p-2">
                            <p><?php echo e(\Carbon\Carbon::parse($acara->penjualan_selesai)->format('d-m-Y')); ?> <span
                                    class="text-gray-500"><?php echo e(\Carbon\Carbon::parse($acara->waktu_selesai)->format('H:i')); ?></span>
                            </p>
                        </div>
                    </div>
                    <div class="border-t border-gray-200 my-4"></div>
                    <p class="text-gray-800 font-medium">lokasi</p>
                    <div class="text-gray-600 mt-2">
                        <?php echo e($acara->lokasi); ?>

                    </div>
                    <div class="border-t border-gray-200 my-4"></div>
                    <p class="text-gray-800 font-medium">Informasi Kontak</p>
                    <div class="text-gray-600 mt-2">
                        <?php echo e($acara->info_kontak); ?>

                    </div>
                    <div class="border-t border-gray-200 my-4"></div>
                    <p class="text-gray-800 font-medium">Status</p>
                    <div class="mt-2">
                        <?php if($acara->status == 'draft'): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                <svg class="mr-1.5 h-2 w-2 text-yellow-400" fill="currentColor" viewBox="0 0 8 8">
                                    <circle cx="4" cy="4" r="3" />
                                </svg>
                                Draft
                            </span>
                        <?php elseif($acara->status == 'published'): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                <svg class="mr-1.5 h-2 w-2 text-green-400" fill="currentColor" viewBox="0 0 8 8">
                                    <circle cx="4" cy="4" r="3" />
                                </svg>
                                Published
                            </span>
                        <?php else: ?>
                            <span class="text-gray-600"><?php echo e($acara->status); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="border-t border-gray-200 my-4"></div>
                    <p class="text-gray-800 font-medium">Informasi Tambahan</p>
                    <div class="flex gap-4 items-center mt-2 justify-between">
                        <p class="text-gray-500">Maks Pembelian Per Akun</p>
                        <div class="text-gray-600">
                            <?php echo e($acara->maks_pembelian_per_akun); ?>

                        </div>
                    </div>
                    <div class="flex gap-4 items-center justify-between mt-2">
                        <p class="text-gray-500">Maks Pembelian Per Transaksi</p>
                        <div class="text-gray-600">
                            <?php echo e($acara->maks_tiket_per_transaksi); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Kulyeah\magang\Project\tukutiket\resources\views/pembeli/tiket/show.blade.php ENDPATH**/ ?>